<?php

namespace App\Livewire\Master\Transactions;

use App\Exports\TransactionTemplateExport;
use App\Imports\TransactionsImport;
use App\Models\AuditLog; // <-- 1. Import Model AuditLog
use App\Models\FinanceCategory;
use App\Models\FinanceTransaction;
use App\Models\Unit;
use App\Models\User;
use App\Notifications\SystemNotification;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\TransactionExport;

#[Layout('components.layouts.app')]
#[Title('Monitoring Transaksi')]
class Index extends Component
{
    use WithPagination, WithFileUploads;

    // Filter Properties
    public string $search = '';
    public string $typeFilter = '';
    public string $statusFilter = '';
    public ?int $unitFilter = null;
    public ?string $startDate = null;
    public ?string $endDate = null;

    // Selection & Bulk Action Properties
    public array $selectedRows = [];
    public bool $selectAll = false;

    // Detail Modal Properties
    public bool $showDetailModal = false;
    public ?FinanceTransaction $selectedTransaction = null;
    public $proofFile = null;

    // Form Modal Properties (Create & Edit)
    public bool $showCreateModal = false;
    public bool $isEditing = false;
    public ?int $editingTransactionId = null;

    public string $form_type = 'income'; // 'income' or 'expense'
    public ?int $form_unit_id = null;
    public ?int $form_finance_category_id = null;
    public ?string $form_transaction_date = null;
    public ?string $form_reference_no = null;
    public string $form_payment_method = 'cash';
    public string $form_status = 'completed';
    public $form_amount = null;
    public ?string $form_description = null;
    public $form_proof_file = null;

    // Import Properties
    public bool $showImportModal = false;
    public bool $showErrorModal = false;
    public array $importErrors = [];
    public $excel_file = null;

    public int $perPage = 15;

    public function mount(): void
    {
        // Sinkronisasi notifikasi transaksi pending saat halaman dibuka
        $this->syncAllTransactionNotifications();
    }

    // Lifecycle Hooks Reset Page
    public function updatingSearch(): void { $this->resetPage(); }
    public function updatingTypeFilter(): void { $this->resetPage(); }
    public function updatingStatusFilter(): void { $this->resetPage(); }
    public function updatingUnitFilter(): void { $this->resetPage(); }
    public function updatingStartDate(): void { $this->resetPage(); }
    public function updatingEndDate(): void { $this->resetPage(); }
    public function updatingPerPage(): void { $this->resetPage(); }

    public function updatedFormUnitId(): void { $this->form_finance_category_id = null; }
    public function updatedFormType(): void { $this->form_finance_category_id = null; }

    // =========================================================================
    // NOTIFIKASI TRANSAKSI PENDING
    // =========================================================================

    /**
     * Jalankan pengecekan notifikasi untuk SEMUA transaksi.
     * Dipanggil saat halaman dimuat & setelah proses import,
     * karena keduanya bisa memengaruhi banyak data sekaligus.
     */
    private function syncAllTransactionNotifications(): void
    {
        FinanceTransaction::all()->each(function (FinanceTransaction $transaction) {
            $this->syncTransactionNotification($transaction);
        });
    }

    /**
     * Sinkronisasi status notifikasi untuk SATU transaksi:
     * - Kirim notifikasi baru jika status 'pending' dan belum ada notifikasi aktif.
     * - Tandai notifikasi lama sebagai dibaca jika status sudah completed/cancelled.
     */
    private function syncTransactionNotification(FinanceTransaction $transaction): void
    {
        $transaction->refresh();

        if ($transaction->status === 'pending') {
            $typeText = $transaction->type === 'income' ? 'Pemasukan' : 'Pengeluaran';

            $this->fireTransactionAlert(
                $transaction,
                'pending_transaction',
                'Transaksi Menunggu Konfirmasi',
                "Transaksi {$typeText} No. Ref {$transaction->reference_no} sebesar Rp " . number_format($transaction->amount, 0, ',', '.') . " berstatus pending dan butuh tindak lanjut."
            );
        } else {
            $this->clearTransactionAlert($transaction, 'pending_transaction');
        }
    }

    private function fireTransactionAlert(FinanceTransaction $transaction, string $type, string $title, string $message): void
    {
        foreach (User::all() as $user) {
            $hasPending = $user->unreadNotifications()
                ->where('data->transaction_id', $transaction->id)
                ->where('data->transaction_alert_type', $type)
                ->exists();

            if (!$hasPending) {
                $user->notify(new SystemNotification(
                    title: $title,
                    message: $message,
                    badge: 'Pending',
                    actionable: false,
                    url: url()->current(),
                    extraData: [
                        'transaction_id'           => $transaction->id,
                        'transaction_alert_type'   => $type,
                    ]
                ));
            }
        }
    }

    private function clearTransactionAlert(FinanceTransaction $transaction, string $type): void
    {
        foreach (User::all() as $user) {
            $user->unreadNotifications()
                ->where('data->transaction_id', $transaction->id)
                ->where('data->transaction_alert_type', $type)
                ->update(['read_at' => now()]);
        }
    }

    public function updatedSelectAll($value): void
    {
        if ($value) {
            $this->selectedRows = $this->getTransactionsQuery()->pluck('id')->map(fn($id) => (string)$id)->toArray();
        } else {
            $this->selectedRows = [];
        }
    }

    public function resetFilters(): void
    {
        $this->reset(['search', 'typeFilter', 'statusFilter', 'unitFilter', 'startDate', 'endDate']);
        $this->resetPage();
    }

    // Modal Create & Edit Methods
    public function openCreateModal(): void
    {
        $this->resetCreateForm();
        $this->isEditing = false;
        $this->editingTransactionId = null;
        $this->form_transaction_date = now()->format('Y-m-d');
        $this->form_reference_no = 'TRX-' . date('Ymd') . '-' . strtoupper(Str::random(4));
        $this->showCreateModal = true;
    }

    public function editTransaction(int $id): void
    {
        $this->resetValidation();
        $transaction = FinanceTransaction::findOrFail($id);

        $this->isEditing = true;
        $this->editingTransactionId = $transaction->id;
        $this->form_type = $transaction->type;
        $this->form_unit_id = $transaction->unit_id;
        $this->form_finance_category_id = $transaction->finance_category_id;
        $this->form_transaction_date = optional($transaction->transaction_date)->format('Y-m-d');
        $this->form_reference_no = $transaction->reference_no;
        $this->form_payment_method = $transaction->payment_method ?? 'cash';
        $this->form_status = $transaction->status ?? 'completed';
        $this->form_amount = $transaction->amount;
        $this->form_description = $transaction->description;

        $this->showCreateModal = true;
    }

    public function closeCreateModal(): void
    {
        $this->showCreateModal = false;
        $this->resetCreateForm();
    }

    public function resetCreateForm(): void
    {
        $this->reset([
            'isEditing', 'editingTransactionId', 'form_type', 'form_unit_id', 
            'form_finance_category_id', 'form_transaction_date', 'form_reference_no', 
            'form_payment_method', 'form_status', 'form_amount', 'form_description', 'form_proof_file'
        ]);
        $this->resetValidation();
    }

    public function saveTransaction(): void
    {
        $validated = $this->validate([
            'form_type' => 'required|in:income,expense',
            'form_unit_id' => 'required|exists:units,id',
            'form_finance_category_id' => [
                'required',
                Rule::exists('finance_categories', 'id')->where(function ($query) {
                    $query->where('unit_id', $this->form_unit_id)
                        ->where('type', $this->form_type);
                }),
            ],
            'form_transaction_date' => 'required|date',
            'form_reference_no' => 'nullable|string|max:50',
            'form_payment_method' => 'required|string',
            'form_status' => 'required|in:completed,pending,cancelled',
            'form_amount' => 'required|numeric|min:1',
            'form_description' => 'nullable|string|max:500',
            'form_proof_file' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ], [], [
            'form_unit_id' => 'Unit Usaha',
            'form_finance_category_id' => 'Kategori Transaksi',
            'form_transaction_date' => 'Tanggal Transaksi',
            'form_amount' => 'Jumlah Nominal',
        ]);

        $data = [
            'unit_id' => $this->form_unit_id,
            'finance_category_id' => $this->form_finance_category_id,
            'user_id' => auth()->id(),
            'reference_no' => $this->form_reference_no ?: 'TRX-' . date('Ymd') . '-' . strtoupper(Str::random(4)),
            'type' => $this->form_type,
            'status' => $this->form_status,
            'payment_method' => $this->form_payment_method,
            'amount' => $this->form_amount,
            'description' => $this->form_description,
            'transaction_date' => $this->form_transaction_date,
        ];

        if ($this->isEditing) {
            $transaction = FinanceTransaction::findOrFail($this->editingTransactionId);
            $oldValues = $transaction->getAttributes();

            if ($this->form_proof_file) {
                if ($transaction->proof_file && Storage::disk('public')->exists($transaction->proof_file)) {
                    Storage::disk('public')->delete($transaction->proof_file);
                }
                $data['proof_file'] = $this->form_proof_file->store('proofs', 'public');
            }

            $transaction->update($data);

            // Audit Log: Edit Transaksi
            AuditLog::record(
                event: 'TRANSACTION_UPDATED',
                identifier: $transaction->reference_no,
                description: "Admin memperbarui data transaksi No. Ref: {$transaction->reference_no}",
                oldValues: $oldValues,
                newValues: $transaction->getAttributes()
            );

            session()->flash('message', 'Transaksi berhasil diperbarui.');
        } else {
            if ($this->form_proof_file) {
                $data['proof_file'] = $this->form_proof_file->store('proofs', 'public');
            }

            $transaction = FinanceTransaction::create($data);

            // Audit Log: Transaksi Baru
            $typeText = $transaction->type === 'income' ? 'Pemasukan' : 'Pengeluaran';
            AuditLog::record(
                event: 'TRANSACTION_CREATED',
                identifier: $transaction->reference_no,
                description: "Admin mencatat transaksi {$typeText} baru: No. Ref {$transaction->reference_no} sebesar Rp " . number_format($transaction->amount, 0, ',', '.'),
                newValues: $transaction->getAttributes()
            );

            session()->flash('message', 'Transaksi baru berhasil dicatat.');
        }

        // Sinkronisasi notifikasi status pending
        $this->syncTransactionNotification($transaction);

        $this->closeCreateModal();
    }

    // Detail Modal Methods
    public function openDetail(int $id): void
    {
        $this->resetValidation();
        $this->reset(['proofFile']);
        $this->selectedTransaction = FinanceTransaction::with(['unit', 'category', 'user'])->find($id);
        $this->showDetailModal = true;
    }

    public function closeDetail(): void
    {
        $this->showDetailModal = false;
        $this->selectedTransaction = null;
        $this->reset(['proofFile']);
    }

    public function uploadProof(): void
    {
        $this->validate([
            'proofFile' => 'required|file|mimes:jpg,jpeg,png,webp,pdf|max:3072',
        ], [
            'proofFile.required' => 'Pilih berkas terlebih dahulu.',
            'proofFile.mimes' => 'Format berkas harus JPG, PNG, WEBP, atau PDF.',
            'proofFile.max' => 'Ukuran berkas maksimal 3 MB.',
        ]);

        if ($this->selectedTransaction) {
            $oldProof = $this->selectedTransaction->proof_file;

            if ($oldProof && Storage::disk('public')->exists($oldProof)) {
                Storage::disk('public')->delete($oldProof);
            }

            $path = $this->proofFile->store('proofs', 'public');
            $this->selectedTransaction->update(['proof_file' => $path]);
            $this->selectedTransaction->refresh();

            // Audit Log: Unggah Bukti
            AuditLog::record(
                event: 'TRANSACTION_PROOF_UPLOADED',
                identifier: $this->selectedTransaction->reference_no,
                description: "Admin mengunggah bukti pembayaran transaksi No. Ref: {$this->selectedTransaction->reference_no}",
                oldValues: ['proof_file' => $oldProof],
                newValues: ['proof_file' => $path]
            );

            $this->reset(['proofFile']);
            session()->flash('message', 'Bukti transaksi berhasil diunggah.');
        }
    }

    public function deleteProof(): void
    {
        if ($this->selectedTransaction && $this->selectedTransaction->proof_file) {
            $oldProof = $this->selectedTransaction->proof_file;

            if (Storage::disk('public')->exists($oldProof)) {
                Storage::disk('public')->delete($oldProof);
            }

            $this->selectedTransaction->update(['proof_file' => null]);
            $this->selectedTransaction->refresh();

            // Audit Log: Hapus Bukti
            AuditLog::record(
                event: 'TRANSACTION_PROOF_DELETED',
                identifier: $this->selectedTransaction->reference_no,
                description: "Admin menghapus berkas bukti pembayaran transaksi No. Ref: {$this->selectedTransaction->reference_no}",
                oldValues: ['proof_file' => $oldProof],
                newValues: null
            );

            session()->flash('message', 'Bukti transaksi berhasil dihapus.');
        }
    }

    // Bulk Action Methods
    public function bulkDelete(): void
    {
        if (empty($this->selectedRows)) return;

        $transactions = FinanceTransaction::whereIn('id', $this->selectedRows)->get();

        foreach ($transactions as $transaction) {
            // Audit Log: Hapus Per Transaksi
            AuditLog::record(
                event: 'TRANSACTION_DELETED',
                identifier: $transaction->reference_no ?? "ID: {$transaction->id}",
                description: "Admin menghapus transaksi No. Ref: {$transaction->reference_no}",
                oldValues: $transaction->getAttributes(),
                newValues: null
            );

            // Bersihkan notifikasi pending terkait transaksi yang akan dihapus
            $this->clearTransactionAlert($transaction, 'pending_transaction');

            if ($transaction->proof_file && Storage::disk('public')->exists($transaction->proof_file)) {
                Storage::disk('public')->delete($transaction->proof_file);
            }

            $transaction->delete();
        }

        $this->selectedRows = [];
        $this->selectAll = false;
        session()->flash('message', 'Transaksi terpilih berhasil dihapus.');
    }

    public function bulkUpdateStatus(string $status): void
    {
        if (empty($this->selectedRows)) return;

        $transactions = FinanceTransaction::whereIn('id', $this->selectedRows)->get();

        foreach ($transactions as $transaction) {
            $oldStatus = $transaction->status;
            
            if ($oldStatus !== $status) {
                $transaction->update(['status' => $status]);

                // Audit Log: Update Status Massal
                AuditLog::record(
                    event: 'TRANSACTION_STATUS_UPDATED',
                    identifier: $transaction->reference_no,
                    description: "Admin mengubah status transaksi {$transaction->reference_no} dari '{$oldStatus}' menjadi '{$status}'",
                    oldValues: ['status' => $oldStatus],
                    newValues: ['status' => $status]
                );
            }

            // Sinkronisasi notifikasi (baik status berubah maupun tidak, aman untuk dijalankan)
            $this->syncTransactionNotification($transaction);
        }

        $this->selectedRows = [];
        $this->selectAll = false;
        session()->flash('message', 'Status transaksi berhasil diperbarui.');
    }

    // Excel Import Methods
    public function openImportModal(): void
    {
        $this->reset('excel_file');
        $this->resetValidation();
        $this->showImportModal = true;
    }

    public function closeImportModal(): void
    {
        $this->showImportModal = false;
        $this->reset('excel_file');
    }

    public function closeErrorModal(): void
    {
        $this->showErrorModal = false;
        $this->importErrors = [];
    }

    public function downloadTemplate()
    {
        return Excel::download(new TransactionTemplateExport, 'Template_Import_Transaksi.xlsx');
    }

    public function importExcel(): void
    {
        $this->validate([
            'excel_file' => 'required|file|mimes:xlsx,xls|max:5120',
        ], [], [
            'excel_file' => 'Berkas Excel'
        ]);

        $fileName = $this->excel_file->getClientOriginalName();
        $import = new TransactionsImport();
        Excel::import($import, $this->excel_file->getRealPath());

        // Cek jika terdapat kegagalan validasi baris dari Excel
        if ($import->failures()->isNotEmpty()) {
            $this->importErrors = [];
            
            foreach ($import->failures() as $failure) {
                $attr = $failure->attribute();
                $columnName = $import->customValidationAttributes()[$attr] ?? $attr;
                $rowValues  = $failure->values();

                foreach ($failure->errors() as $error) {
                    $this->importErrors[] = [
                        'row'      => $failure->row(),
                        'column'   => $columnName,
                        'value'    => $rowValues[$attr] ?? '(Kosong)',
                        'messages' => $error,
                    ];
                }
            }

            // Audit Log: Impor Gagal
            AuditLog::record(
                event: 'TRANSACTION_IMPORT_FAILED',
                identifier: $fileName,
                description: "Admin gagal melakukan impor data transaksi dari berkas '{$fileName}'. Terdapat kesalahan validasi."
            );

            $this->showImportModal = false;
            $this->showErrorModal = true;
            return;
        }

        // Audit Log: Impor Sukses
        AuditLog::record(
            event: 'TRANSACTION_IMPORTED',
            identifier: $fileName,
            description: "Admin berhasil mengimpor data transaksi melalui berkas Excel",
            newValues: [
                'nama_file'   => $fileName,
                'ukuran_file' => round($this->excel_file->getSize() / 1024, 2) . ' KB',
                'waktu_impor' => now()->translatedFormat('d F Y H:i:s'),
            ]
        );

        // Sinkronisasi notifikasi karena import bisa menambahkan banyak transaksi pending sekaligus
        $this->syncAllTransactionNotifications();

        $this->closeImportModal();
        session()->flash('message', 'Data transaksi dari Excel berhasil diimpor.');
    }

    private function getTransactionsQuery()
    {
        return FinanceTransaction::with(['unit', 'category', 'user'])
            ->when($this->search, function ($q) {
                $q->where(function ($sub) {
                    $sub->where('description', 'like', "%{$this->search}%")
                        ->orWhere('reference_no', 'like', "%{$this->search}%");
                });
            })
            ->when($this->unitFilter, fn ($q) => $q->where('unit_id', $this->unitFilter))
            ->when($this->typeFilter, fn ($q) => $q->where('type', $this->typeFilter))
            ->when($this->statusFilter, fn ($q) => $q->where('status', $this->statusFilter))
            ->when($this->startDate, fn ($q) => $q->whereDate('transaction_date', '>=', $this->startDate))
            ->when($this->endDate, fn ($q) => $q->whereDate('transaction_date', '<=', $this->endDate));
    }

    public function exportData()
    {
        $filters = [
            'search'      => $this->search,
            'unitFilter'  => $this->unitFilter,
            'typeFilter'  => $this->typeFilter,
            'statusFilter'=> $this->statusFilter,
            'startDate'   => $this->startDate,
            'endDate'     => $this->endDate,
        ];

        $fileName = 'Data_Transaksi_' . now()->format('Ymd_His') . '.xlsx';

        // Audit Log: Export Data
        AuditLog::record(
            event: 'TRANSACTION_EXPORTED',
            identifier: $fileName,
            description: "Admin mengekspor data transaksi ke Excel" . 
                ($this->unitFilter ? " (Unit ID: {$this->unitFilter})" : '') .
                ($this->startDate || $this->endDate ? " periode {$this->startDate} s/d {$this->endDate}" : ''),
        );

        return Excel::download(new TransactionExport($filters), $fileName);
    }

    public function render()
    {
        $kpiQuery = FinanceTransaction::query()
            ->when($this->search, function ($q) {
                $q->where(function ($sub) {
                    $sub->where('description', 'like', "%{$this->search}%")
                        ->orWhere('reference_no', 'like', "%{$this->search}%");
                });
            })
            ->when($this->unitFilter, fn ($q) => $q->where('unit_id', $this->unitFilter))
            ->when($this->startDate, fn ($q) => $q->whereDate('transaction_date', '>=', $this->startDate))
            ->when($this->endDate, fn ($q) => $q->whereDate('transaction_date', '<=', $this->endDate));

        $totalIncome  = (clone $kpiQuery)->where('type', 'income')->where('status', 'completed')->sum('amount');
        $totalExpense = (clone $kpiQuery)->where('type', 'expense')->where('status', 'completed')->sum('amount');
        $pendingCount = (clone $kpiQuery)->where('status', 'pending')->count();
        $netBalance   = $totalIncome - $totalExpense;

        $transactions = $this->getTransactionsQuery()
            ->latest('transaction_date')
            ->latest('id')
            ->paginate($this->perPage);

        $categories = $this->form_unit_id
            ? FinanceCategory::query()
                ->where('unit_id', $this->form_unit_id)
                ->when($this->form_type, function ($q) {
                    $q->whereRaw('LOWER(type) = ?', [strtolower($this->form_type)]);
                })
                ->orderBy('name')
                ->get()
            : collect();

        return view('livewire.master.transactions.index', compact(
            'transactions', 'totalIncome', 'totalExpense', 'netBalance', 'pendingCount', 'categories'
        ))->with('units', Unit::orderBy('name')->get());
    }
}